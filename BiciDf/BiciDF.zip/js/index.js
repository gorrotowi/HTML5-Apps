var mapa;

function iniciarMapa() {
    var mapOptions = {
        zoom: 8,
        center: new google.maps.LatLng(-34.397, 150.644),
        mapTypeId: google.maps.MapTypeId.ROADMAP
    };

    var marker = new google.maps.Marker({
        position: new google.maps.LatLng(-34.397, 150.644),
        //icon:iconomarker,
        animation: 'DROP',
        title: "Usted esta aqui."
    });

    map = new google.maps.Map(document.getElementById('mapa'),
        mapOptions);
    marker.setMap(map);
}

google.maps.event.addDomListener(window, 'load', iniciarMapa);